/************************************************************************
Numerus Ltd

Purpose            : Creates successful findign of solution within 
                     weighted IPD to AGR tolerances check AD

************************************************************************/;

libname AD 'path\SAS Files';


proc sort data=AD.ADMETRICS out=SUC1(keep=SCENARIO TREAT SIGN_SUC POLYS_SUC POLYI_SUC JACK_SUC GROUP:) nodupkey;
 by SCENARIO TREAT;
run;

proc transpose data=AD.ADMETRICS out=ess1;
 var ESSP;
 id METHOD2 SET_TOLS;
 by SCENARIO TREAT;
 where index(METHOD2,'vs')=0;
run;

proc transpose data=AD.ADMETRICS out=onefl1(rename=(SIGNMAICNA=SIGNONEFL POLYMAIC2SUCCESS_CRIT=POLYIONEFL POLYMAIC1SIG_TOLS=POLYSONEFL JACKMAICNA=JACKONEFL));
 var ONEFL;
 id METHOD2 SET_TOLS;
 by SCENARIO TREAT;
 where index(METHOD2,'vs')=0;
run;

proc transpose data=AD.ADMETRICS out=poolfl1(rename=(SIGNMAICNA=SIGNPOOLFL POLYMAIC2SUCCESS_CRIT=POLYIPOOLFL POLYMAIC1SIG_TOLS=POLYSPOOLFL JACKMAICNA=JACKPOOLFL));
 var POOLFL;
 id METHOD2 SET_TOLS;
 by SCENARIO TREAT;
 where index(METHOD2,'vs')=0;
run;

proc sort data=AD.DATA out=DATA1(drop=SUBJID Xdata1--Xdata5) nodupkey;
 by SCENARIO TREAT;
run;

data AD.ADSUCCESS;
 merge SUC1 
       DATA1  
       ess1(rename=(POLYMAIC1SIG_TOLS=POLYSESSP POLYMAIC2SUCCESS_CRIT=POLYIESSP SIGNMAICNA=SIGNESSP JACKMAICNA=JACKESSP) 
            keep=SCENARIO TREAT POLYMAIC1SIG_TOLS POLYMAIC2SUCCESS_CRIT SIGNMAICNA JACKMAICNA)
       onefl1(keep = SCENARIO TREAT SIGNONEFL POLYSONEFL POLYIONEFL JACKONEFL)
       poolfl1(keep = SCENARIO TREAT SIGNPOOLFL POLYSPOOLFL POLYIPOOLFL JACKPOOLFL);
 by SCENARIO TREAT;
 if X1n>.;
 BINSUM=(XD1='BI')+(XD2='BI')+(XD3='BI')+(XD4='BI')+(XD5='BI');
 NORSUM=(XD1='NM')+(XD2='NM')+(XD3='NM')+(XD4='NM')+(XD5='NM');
 LOGSUM=(XD1='LN')+(XD2='LN')+(XD3='LN')+(XD4='LN')+(XD5='LN');
 VARSUM=BINSUM+NORSUM+LOGSUM;
 label POLYSESSP='POLY (SIGN tols) ESS %'
       POLYIESSP='POLY (IND tols) ESS %'
        SIGNESSP='SIGN ESS %'
        JACKESSP='JACK ESS %'
        BINSUM='# binary chars.'
        NORSUM='# normal chars.'
        LOGSUM='# log-normal chars.'
        VARSUM='# characteristics';
  
  SIGNONEFL = coalescec(SIGNONEFL, "N");
  POLYSONEFL = coalescec(POLYSONEFL, "N"); 
  POLYIONEFL = coalescec(POLYIONEFL, "N"); 
  JACKONEFL = coalescec(JACKONEFL, "N");
  
  SIGNPOOLFL = coalescec(SIGNPOOLFL, "N");
  POLYSPOOLFL = coalescec(POLYSPOOLFL, "N"); 
  POLYIPOOLFL = coalescec(POLYIPOOLFL, "N"); 
  JACKPOOLFL = coalescec(JACKPOOLFL, "N");
run;


* eof;

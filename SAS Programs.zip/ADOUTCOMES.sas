/************************************************************************
Numerus Ltd

Purpose            : Creates the IPD and target IPD/AgD outcome 
                     data for each scenario
************************************************************************/;

libname AD 'path\SAS Files';


* Creates outcomes (continous and binomial, with/without treatment-characteristic interaction) ;

proc sort data=AD.DATA out=d1(keep=Scenario) nodupkey;
 by Scenario;
run;

* Assumes 4 outcome models for both unanchored and anchored;

data d2;
 set d1;
 array   C{3,7} C11-C17 C21-C27 C31-C37;
   do i=1 to 3;
    do j=1 to 7;
     do until(abs(C{i,j})>0.3); * Ensure that regression covariates are not close to zero;
     C{i,j}=normal(1814);
     end; 
    end;
   end;
run;


data d3;
 set AD.DATA;
 keep Scenario SUBJID Treat TreatT Xdata1--XTdata5; 
run;

data d4;
 merge d3 d2;
 by Scenario;
run;

data d5;
 call streaminit(425);
 set d4;
 array  Xdata{5} Xdata1-Xdata5; 
 array  XTdata{5} XTdata1-XTdata5; 
 do i=1 to 5;
  if Xdata[i]=.  then Xdata[i]=0;
  if XTdata[i]=. then XTdata[i]=0;
 end;

 **************************************************
 *** Unanchored - outcome predictors only - active arms only (TX=1) *********;


  * Continous outcomes;
   if TREAT=1  then LP1=C11*Xdata1 +C12*Xdata2 +C13*Xdata3 +C14*Xdata4 +C15*Xdata5;
   if TREATT=1 then LP2=C11*XTdata1+C12*XTdata2+C13*XTdata3+C14*XTdata4+C15*XTdata5;

   UNICON=LP1 + 2*normal(1611); * IPD;
   UNACON=LP2 + 2*normal(6237); * ALD;

  * Binomial outcomes;
   B11=exp(LP1/0.5)/(1+exp(LP1/0.5));* IPD;
   B21=exp(LP2/0.5)/(1+exp(LP2/0.5));* ALD;

   UNIBIN=rand("Bernoulli",B11); * IPD;
   UNABIN=rand("Bernoulli",B21); * ALD;

  
 ****************************************************************
 ***Anchored - outcome predictors & tx-effect modifiers *********;

 * Continous outcomes;
  LP3=C21*Xdata1 +C22*Xdata2 +C23*Xdata3 +C24*Xdata4 +C25*Xdata5 + TREAT *(C31*Xdata1 +C32*Xdata2 +C33*Xdata3 +C34*Xdata4 +C35*Xdata5) ;
  LP4=C21*XTdata1+C22*XTdata2+C23*XTdata3+C24*XTdata4+C25*XTdata5+ TREATT*(C31*XTdata1+C32*XTdata2+C33*XTdata3+C34*XTdata4+C35*XTdata5);

  ANICON=LP3 + 2*normal(8254);* IPD;
  ANACON=LP4 + 2*normal(9407);* ALD;

 * Binomial outcomes;
  B31=exp(LP3/0.5)/(1+exp(LP3/0.5));* IPD;
  B41=exp(LP4/0.5)/(1+exp(LP4/0.5));* ALD;

  ANIBIN=rand("Bernoulli",B31);* IPD;
  ANABIN=rand("Bernoulli",B41);* ALD;

  label UNICON='Outcome: Unanchored, continuous, IPD' UNACON='Outcome: Unanchored, continuous, ALD' 
        ANICON='Outcome: Anchored, continuous, IPD'   ANACON='Outcome: Anchored, continuous, ALD'
		UNIBIN='Outcome: Unanchored, binary, IPD'     UNABIN='Outcome: Unanchored, binary, ALD' 
        ANIBIN='Outcome: Anchored, binary, IPD'       ANABIN='Outcome: Anchored, binary, ALD';


run;


data AD.ADOUTCOMES(label='MAIC simulation outcome data');
 set d5;
 keep Scenario--XTdata5 TREAT: UN: AN:;
 format UNICON UNACON ANICON ANACON 8.3;
run;


* eof;

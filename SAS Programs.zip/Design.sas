/************************************************************************
Numerus Ltd

Purpose            : Creates the IPD and target IPD/AgD for each scenario

************************************************************************/;

libname AD 'path\SAS Files';


* Reads in DoE design from SAS JMP;
* Labels each factor ;

data d1;
 set AD.design1;
 drop Y;
 label X1='Sample size'
       X2='Correlation'	
       X3='Dist #1'
       X4='Dist #1: Location target imbalance'	
       X5='Dist #1: Spread target imbalance'
       X6='Dist #2'
       X7='Dist #2: Location target imbalance'	
       X8='Dist #2: Spread target imbalance'
       X9='Dist #3'
       X10='Dist #3: Location target imbalance'	
       X11='Dist #3: Spread target imbalance'
       X12='Dist #4'
       X13='Dist #4: Location target imbalance'	
       X14='Dist #4: Spread target imbalance'
       X15='Dist #5'
       X16='Dist #5: Location target imbalance'	
       X17='Dist #5: Spread target imbalance';
run;

proc freq;table X1--X17;run;

* Repeat the design data to include additional scenarios, in order to ensure and equal number of of scenarios with 1-5 characteristics;
data d1a;
 set d1 d1(in=a);
 if a then do;
 N1+1;
 * Convert scenarios to just 1-3 characteristics;
 if      N1<=503 then do;X6='L4';X9='L4';X12='L4';X15='L4';end; 
 if 504<=N1<=956 then do;        X9='L4';X12='L4';X15='L4';end; 
 if 957<=N1<=1231 then do;               X12='L4';X15='L4';end; 
 if N1>=1232 then delete;
 end;
run;

* Characterises factor levels;

data d2; 
 format Scenario X1n X2  XM: XS: TM: TS:;
 set d1a;
 array   X{5} $ X3  X6  X9  X12  X15 ;
 array  XD{5} $  XD1 XD2 XD3 XD4 XD5;
 array  XM{5}   XM1 XM2 XM3 XM4 XM5;
 array  XS{5}   XS1 XS2 XS3 XS4 XS5;

 Scenario+1;

 * Sample sizes (# subjects) 
 if X1='L1' then X1n=100;
 if X1='L2' then X1n=200;
 if X1='L3' then X1n=500;
 if X1='L4' then X1n=1000;

  * Correlations;
 if X2='L1' then  do;X2='NO';X2C=0.0;end;*None;
 if X2='L2' then  do;X2='LO';X2C=0.2;end;*Weak;
 if X2='L3' then  do;X2='ME';X2C=0.4;end;*Moderate;  

 do i=1 to 5;

 * Distribution of baseline chracteristics;
   if X{i}='L1' then XD{i}='NM'; * Normal;
   if X{i}='L2' then XD{i}='BI'; * Binomial;
   if X{i}='L3' then XD{i}='LN'; * Log-normal;
   if X{i}='L4' then XD{i}='NA'; * Not applicable;

 * IPD means/SDs;
   if  XD{i}='NM' then do; XM{i}=0;                    XS{i}=exp(normal(1234));end;
   if  XD{i}='BI' then do; XM{i}=0.2+0.6*ranuni(8366); XS{i}=0;end; * Limits sample proportion to between 20 and 80%;
   if  XD{i}='LN' then do; XM{i}=0;                    XS{i}=exp(normal(5678));end;

 end;

 drop i X1 X3 X6 X9 X12 X15; 

 * Remove scenarios which include solely binomial variables;
 if XD1 ~in ('NM' 'LN') and XD2 ~in ('NM' 'LN') and XD3 ~in ('NM' 'LN') and XD4 ~in ('NM' 'LN') and XD5 ~in ('NM' 'LN') then delete; 

 label Scenario='Scenario #' X1n='Sample size (subjects)' X2C='Correlation (r)'
  
       XD1='Dist #1: type' XD2='Dist #2: type' XD3='Dist #3: type' XD4='Dist #4: type' XD5='Dist #5: type'

       XM1='Dist #1: IPD Mean' XS1='Dist #1: IPD SD'
       XM2='Dist #2: IPD Mean' XS2='Dist #2: IPD SD'
       XM3='Dist #3: IPD Mean' XS3='Dist #3: IPD SD'
       XM4='Dist #4: IPD Mean' XS4='Dist #4: IPD SD'
       XM5='Dist #5: IPD Mean' XS5='Dist #5: IPD SD'
;
run;

data d2a;
 set d2;
 * number of distributions/characteristics per scenario;
 BINSUM=(XD1='BI')+(XD2='BI')+(XD3='BI')+(XD4='BI')+(XD5='BI');
 NORSUM=(XD1='NM')+(XD2='NM')+(XD3='NM')+(XD4='NM')+(XD5='NM');
 LOGSUM=(XD1='LN')+(XD2='LN')+(XD3='LN')+(XD4='LN')+(XD5='LN');
 VARSUM=BINSUM+NORSUM+LOGSUM;
run;

proc sort data=d2a;
 by varsum;
run;

data d2b;
 set d2a;
 by varsum;
 if first.varsum then F1=1;
 else F1+1;
 if f1<=400;* Retain 400 scenarios per # characteristics;
run;
proc freq data=d2b;
 table BINSUM NORSUM LOGSUM varsum;
run;
proc sort data=d2b;
 by Scenario;
run;


* Simulates multivariate normal [N(0,1)] correlated data ;

data d3;
 set d2b;
 keep Scenario X2C;
run;
data d4(TYPE=CORR);
 set d3;
 _TYPE_='MEAN';ND1=0;ND2=0;ND3=0;ND4=0;ND5=0;output;
 _TYPE_='STD' ;ND1=1;ND2=1;ND3=1;ND4=1;ND5=1;output;
 _TYPE_='CORR' ;_NAME_='ND1';ND1=1;ND2=X2C;ND3=X2C;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND2';ND1=X2C;ND2=1;ND3=X2C;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND3';ND1=X2C;ND2=X2C;ND3=1;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND4';ND1=X2C;ND2=X2C;ND3=X2C;ND4=1;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND5';ND1=X2C;ND2=X2C;ND3=X2C;ND4=X2C;ND5=1;output;
run;
proc simnormal data=d4 outsim=d5 numreal = 1000 seed = 51621;    * Sample 1000 subjects for each scenario;  
   var ND1 ND2 ND3 ND4 ND5 ;
   by Scenario;
run;    

data d6;
 merge d2 d5(in=a);
 by Scenario;
 if a;
 if Rnum<=X1n;* only retain the number of subjects for each scenario;
 TREAT=((_N_+1)/2)=int(((_N_+1)/2));* Binary treatment indicator;
 rename  Rnum=SUBJID;
 label Rnum='Subject ID' TREAT='Treatment';
 format XM: XS: 6.2;
run;


* Simulates subject-level data;

data d7;
 call streaminit(3992);
 set d6;
  array   ND{5} $ ND1  ND2  ND3  ND4  ND5;
  array   XD{5} $ XD1  XD2  XD3  XD4  XD5;
  array   XM{5}   XM1  XM2  XM3  XM4  XM5;
  array   XS{5}   XS1  XS2  XS3  XS4  XS5;
  array   Xdata{5} Xdata1 Xdata2 Xdata3 Xdata4 Xdata5;
   do i=1 to 5;
    if XD{i}='NM' then Xdata{i}=XM{i}+XS{i}*ND{i};            *Normal data;
    if XD{i}='BI' then Xdata{i}=(cdf('Normal',ND{i})<=XM{i}); *Binomial data;
    if XD{i}='LN' then Xdata{i}=(XM{i}+ND{i})**2;             *Chi-square data;
   end;
 label Xdata1='Dist #1: IPD' Xdata2='Dist #2: IPD' Xdata3='Dist #3: IPD' Xdata4='Dist #4: IPD' Xdata5='Dist #5: IPD';
 drop i ND1--ND5;
 format Xdata: 6.1;
run;

* Calculate actual IPD summary stats;

proc means data=d7 noprint;
 var Xdata:;
 by Scenario;
 output out=IPDSTATS mean=XD1M XD2M XD3M XD4M XD5M std=XD1S XD2S XD3S XD4S XD5S;
run;


data d8;
 merge d7 IPDSTATS;
 by Scenario;
 drop _TYPE_ _FREQ_; 
run;


* Set summary-level targets;

data d9;

 array  XD{5} $ XD1 XD2 XD3 XD4 XD5;
 array  MT{5} $ X4 X7 X10 X13 X16;
 array  ST{5} $ X5 X8 X11 X14 X17;
 array  XM{5}   XD1M XD2M XD3M XD4M XD5M;
 array  XS{5}   XD1S XD2S XD3S XD4S XD5S;
 array  TM{5}   TM1 TM2 TM3 TM4 TM5;
 array  TMx{5}  TMx1 TMx2 TMx3 TMx4 TMx5;
 array  TS{5}   TS1 TS2 TS3 TS4 TS5;

 set d8;

 do i=1 to 5;

   * Location targets;

    if XD{i} = 'NM' and MT{i}='L7' then TM{i}=XM{i}+0.3*XS{i};   
    if XD{i} = 'NM' and MT{i}='L6' then TM{i}=XM{i}+0.2*XS{i};   
    if XD{i} = 'NM' and MT{i}='L5' then TM{i}=XM{i}+0.1*XS{i};   
    if XD{i} = 'NM' and MT{i}='L4' then TM{i}=XM{i}+0.0*XS{i};            
    if XD{i} = 'NM' and MT{i}='L3' then TM{i}=XM{i}-0.1*XS{i};   
    if XD{i} = 'NM' and MT{i}='L2' then TM{i}=XM{i}-0.2*XS{i};   
    if XD{i} = 'NM' and MT{i}='L1' then TM{i}=XM{i}-0.3*XS{i};  

    if XD{i} = 'NM' and ST{i}='L5' then TS{i}=1.20*XS{i}; 
    if XD{i} = 'NM' and ST{i}='L4' then TS{i}=1.10*XS{i}; 
    if XD{i} = 'NM' and ST{i}='L3' then TS{i}=1.00*XS{i}; 
    if XD{i} = 'NM' and ST{i}='L2' then TS{i}=0.90*XS{i}; 
    if XD{i} = 'NM' and ST{i}='L1' then TS{i}=0.80*XS{i}; 

    if XD{i} = 'LN' and MT{i}='L7' then TM{i}=1.15*XM{i};   
    if XD{i} = 'LN' and MT{i}='L6' then TM{i}=1.10*XM{i};   
    if XD{i} = 'LN' and MT{i}='L5' then TM{i}=1.05*XM{i};   
    if XD{i} = 'LN' and MT{i}='L4' then TM{i}=1.00*XM{i};            
    if XD{i} = 'LN' and MT{i}='L3' then TM{i}=0.95*XM{i};   
    if XD{i} = 'LN' and MT{i}='L2' then TM{i}=0.90*XM{i};   
    if XD{i} = 'LN' and MT{i}='L1' then TM{i}=0.85*XM{i};  

    if XD{i} = 'LN' and ST{i}='L5' then TS{i}=1.00*XS{i}; 
    if XD{i} = 'LN' and ST{i}='L4' then TS{i}=1.00*XS{i}; 
    if XD{i} = 'LN' and ST{i}='L3' then TS{i}=1.00*XS{i}; 
    if XD{i} = 'LN' and ST{i}='L2' then TS{i}=1.00*XS{i}; 
    if XD{i} = 'LN' and ST{i}='L1' then TS{i}=1.00*XS{i}; 

    if XD{i} = 'BI' and MT{i}='L7' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}+0.6)/(1+exp(TMx{i}+0.6));end;
    if XD{i} = 'BI' and MT{i}='L6' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}+0.4)/(1+exp(TMx{i}+0.4));end;
    if XD{i} = 'BI' and MT{i}='L5' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}+0.2)/(1+exp(TMx{i}+0.2));end;
    if XD{i} = 'BI' and MT{i}='L4' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}+0.0)/(1+exp(TMx{i}+0.0));end;
    if XD{i} = 'BI' and MT{i}='L3' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}-0.2)/(1+exp(TMx{i}-0.2));end;
    if XD{i} = 'BI' and MT{i}='L2' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}-0.4)/(1+exp(TMx{i}-0.4));end;
    if XD{i} = 'BI' and MT{i}='L1' then do;TMx{i}=log(XM{i}/(1-XM{i}));TM{i}=exp(TMx{i}-0.6)/(1+exp(TMx{i}-0.6));end;
 
   end;

 format TM: TS: 6.2;
 label
       TM1='Dist #1: Target Mean' TS1='Dist #1: Target SD'
       TM2='Dist #2: Target Mean' TS2='Dist #2: Target SD'
       TM3='Dist #3: Target Mean' TS3='Dist #3: Target SD'
       TM4='Dist #4: Target Mean' TS4='Dist #4: Target SD'
       TM5='Dist #5: Target Mean' TS5='Dist #5: Target SD'
 ;
run;





*****************************************************
* Simulate TARGET IPD;
*****************************************************;


* Simulates multivariate normal [N(0,1)] correlated data ;

data d3_TAR;
 set d2b;
 keep Scenario X2C;
run;
data d4_TAR(TYPE=CORR);
 set d3_TAR;
 _TYPE_='MEAN';ND1=0;ND2=0;ND3=0;ND4=0;ND5=0;output;
 _TYPE_='STD' ;ND1=1;ND2=1;ND3=1;ND4=1;ND5=1;output;
 _TYPE_='CORR' ;_NAME_='ND1';ND1=1;ND2=X2C;ND3=X2C;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND2';ND1=X2C;ND2=1;ND3=X2C;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND3';ND1=X2C;ND2=X2C;ND3=1;ND4=X2C;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND4';ND1=X2C;ND2=X2C;ND3=X2C;ND4=1;ND5=X2C;output;
 _TYPE_='CORR' ;_NAME_='ND5';ND1=X2C;ND2=X2C;ND3=X2C;ND4=X2C;ND5=1;output;
run;
proc simnormal data=d4_TAR outsim=d5_TAR numreal = 1000 seed = 42562;    * Sample 1000 subjects for each scenario;  
   var ND1 ND2 ND3 ND4 ND5 ;
   by Scenario;
run;    


proc sort data=d9 out=dTAR(keep=Scenario XD1--XD5 X1n TM1--TM5 TS1--TS5) nodupkey;
 by Scenario;
run;

data d2_TAR;
 set dTAR;
run;

data d6_TAR;
 merge d2_TAR d5_TAR(in=a);
 by Scenario;
 if a;
 if Rnum<=X1n;* only retain the number of subjects for each scenario;
 TREATT=((_N_+1)/2)=int(((_N_+1)/2));* Binary treatment indicator;
 rename  Rnum=SUBJID;
 label Rnum='Subject ID' TREATT='Treatment (target)';
 format XM: XS: 6.2;
run;

* Simulates TARGET subject-level data;

data d7_TAR;
 call streaminit(1536);
 set d6_TAR;
  array   ND{5} $ ND1  ND2  ND3  ND4  ND5;
  array   XD{5} $ XD1  XD2  XD3  XD4  XD5;
  array   TM{5}   TM1  TM2  TM3  TM4  TM5;
  array   TS{5}   TS1  TS2  TS3  TS4  TS5;
  array   XTdata{5} XTdata1 XTdata2 XTdata3 XTdata4 XTdata5;
   do i=1 to 5;
    if XD{i}='NM' then XTdata{i}=TM{i}+TS{i}*ND{i};            *Normal data;
    if XD{i}='BI' then XTdata{i}=(cdf('Normal',ND{i})<=TM{i}); *Binomial data;
    if XD{i}='LN' then XTdata{i}=(TM{i}+ND{i})**2;             *Chi-square data;
   end;
 label XTdata1='Target Dist #1: IPD' XTdata2='Target Dist #2: IPD' XTdata3='Target Dist #3: IPD' XTdata4='Target Dist #4: IPD' XTdata5='Target Dist #5: IPD';
 drop i ND1--ND5;
 format XTdata: 6.1;
run;

* Calculate actual TARGET IPD summary stats;

proc sort data=d7_TAR;
 by Scenario TREATT;
run;

* Active TX;
proc means data=d7_TAR noprint;
 var XTdata:;
 by Scenario;
 where TREATT=1;
 output out=IPDSTATS_TART mean=TMT1 TMT2 TMT3 TMT4 TMT5 std=TST1 TST2 TST3 TST4 TST5;
run;

* Anchor TX;
proc means data=d7_TAR noprint;
 var XTdata:;
 by Scenario;
 where TREATT=0;
 output out=IPDSTATS_TARP mean=TMP1 TMP2 TMP3 TMP4 TMP5 std=TSP1 TSP2 TSP3 TSP4 TSP5;
run;


data d8_TAR;
 merge d7_TAR IPDSTATS_TART IPDSTATS_TARP;
 by Scenario;
 format TM: TS: 6.2;
 label
       TMT1='Dist #1: Target Active Mean' TST1='Dist #1: Target Active SD'
       TMT2='Dist #2: Target Active Mean' TST2='Dist #2: Target Active SD'
       TMT3='Dist #3: Target Active Mean' TST3='Dist #3: Target Active SD'
       TMT4='Dist #4: Target Active Mean' TST4='Dist #4: Target Active SD'
       TMT5='Dist #5: Target Active Mean' TST5='Dist #5: Target Active SD'

       TMP1='Dist #1: Target Anchor Mean' TSP1='Dist #1: Target Anchor SD'
       TMP2='Dist #2: Target Anchor Mean' TSP2='Dist #2: Target Anchor SD'
       TMP3='Dist #3: Target Anchor Mean' TSP3='Dist #3: Target Anchor SD'
       TMP4='Dist #4: Target Anchor Mean' TSP4='Dist #4: Target Anchor SD'
       TMP5='Dist #5: Target Anchor Mean' TSP5='Dist #5: Target Anchor SD'
 ;
 drop _TYPE_ _FREQ_; 
run;


data d9_TAR;
 set d8_TAR;
 keep Scenario SUBJID TREATT XTdata1--XTdata5 TMT1--TSP5;
run;


data d10;
 set d9;
 drop  i XD1M XD2M XD3M XD4M XD5M XD1S XD2S XD3S XD4S XD5S TMX1 TMX2 TMX3 TMX4 TMX5 XM1--XM5 XS1--XS5 N1 TM1--TM5 TS1--TS5;
run;


proc sort data=d9_TAR;
 by Scenario SUBJID;
run;

data AD.data(label='MAIC simulation data');
 format Scenario X1n X2 X2C XD1 XD2 XD3 XD4 XD5 X4 X5 X7 X8 X10 X11 X13 X14 X16 X17 TMT1 TST1 TMT2 TST2 TMT3 TST3 TMT4 TST4 TMT5 TST5 TMP1 TSP1 TMP2 TSP2 TMP3 TSP3 TMP4 TSP4 TMP5 TSP5; 
 merge d10 d9_TAR;
 by Scenario SUBJID;
run;


proc sort data=AD.DATA out=DATA1(drop=SUBJID--Xdata5) nodupkey;
 by Scenario;
run;


data chk;
 set DATA1;
 if X1n>.;
 BINSUM=(XD1='BI')+(XD2='BI')+(XD3='BI')+(XD4='BI')+(XD5='BI');
 NORSUM=(XD1='NM')+(XD2='NM')+(XD3='NM')+(XD4='NM')+(XD5='NM');
 LOGSUM=(XD1='LN')+(XD2='LN')+(XD3='LN')+(XD4='LN')+(XD5='LN');
 VARSUM=BINSUM+NORSUM+LOGSUM;
run;


proc freq data=chk;
 table varsum BINSUM NORSUM LOGSUM x1n X2;
run;
proc freq data=chk;
 table NORSUM*LOGSUM*BINSUM / list missing out=ss1;
run;
proc sort data=ss1;by descending count;run;
data ss2;
 set ss1;
 if NORSUM>=2 then NORSUM=2;
 if LOGSUM>=2 then LOGSUM=2;
 if BINSUM>=2 then BINSUM=2;
run;
proc freq data=ss2;
 table NORSUM*LOGSUM*BINSUM / list missing out=ss3;
 weight COUNT;
run;
proc sort data=ss3;by descending count;run;
data ss4;
 set ss3;
 tab=put(NORSUM,1.0)||','||put(LOGSUM,1.0)||','||put(BINSUM,1.0);
run;
proc print data=ss4;var tab count;run;

* eof;

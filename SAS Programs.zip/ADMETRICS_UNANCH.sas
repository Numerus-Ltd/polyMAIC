/************************************************************************
Numerus Ltd

Purpose            : Reads in simulation results from R and 
                     creates performance metrics AD

************************************************************************/


libname ad 'path\SAS Files';

data WORK.d1    ;
      %let _EFIERR_ = 0; /* set the ERROR detection macro variable */
      infile 'path\R Files\FINAL_DIAGNOSTICS_UNANCHALL.csv' delimiter = ',' MISSOVER DSD lrecl=32767 firstobs=2;
   informat METHOD2 $22. ;
   informat TREAT best32.;
   informat SIM best32. ;
   informat N best32.;
   informat ESS best32. ;
   informat ESSP best32. ;
   informat IPWP best32. ;
   informat IPWP_FIXED best32. ;
   informat WMAX best32. ;
   informat VARIANCE best32. ;
   informat ENTROPY best32. ;
   informat SET_TOLS $14. ;
   informat POOLFL $1.;
   informat ONEFL $1.;
   format METHOD2 $22. ;
   format TREAT best32.;
   format SIM best32. ;
   format N best32.;
   format ESS best32. ;
   format ESSP best32. ;
   format IPWP best32. ;
   format IPWP_FIXED best32. ;
   format WMAX best32. ;
   format VARIANCE best32. ;
   format ENTROPY best32. ;
   format SET_TOLS $14. ;
   format POOLFL $1.;
   format ONEFL $1.;
input
            METHOD2 $
			TREAT
			SIM
			N
            ESS
            ESSP
            IPWP
            IPWP_FIXED
			WMAX
			VARIANCE
            ENTROPY
			SET_TOLS $
            POOLFL $ 
			ONEFL $

;
      if _ERROR_ then call symputx('_EFIERR_',1);  /* set ERROR detection macro variable */
run;

%put ErrorN = &_EFIERR_.;

data d2;
 set d1;
 ESSP=100*ESSP;
 IPWP=100*IPWP;
 IPWP_FIXED=100*IPWP_FIXED;
 SD=sqrt(VARIANCE);
 format ESS WMAX ENTROPY ESSP IPWP IPWP_FIXED 6.1 VARIANCE SD 6.2;
 if SET_TOLS = "" then SET_TOLS = "NA";
 else if SET_TOLS = "SIG TOLS" then SET_TOLS = "SIG_TOLS";
 else if SET_TOLS = "SUCCESS CRIT" then SET_TOLS = "SUCCESS_CRIT";
run;

/* Check whether at least one method failed computationally by scenario, i.e, ONEFL = "Y" for at least SIGNMAIC, POLYMAIC2, and JACKMAIC */
proc sort data=d1; by SIM ONEFL; run;

data failfl(keep = SCENARIO FAILFL);
  set d1(where=(upcase(METHOD2) in ("SIGNMAIC", "POLYMAIC2", "JACKMAIC")));
  by SIM ONEFL;
  rename ONEFL = FAILFL
         SIM = SCENARIO;
  if last.SIM then output;
run;

proc freq data=failfl;
  table FAILFL / missing;
run;

* Pairwise differences;
proc sort data=d2; by SIM TREAT; run;
 
proc transpose data=d2 out=d3;
 var ESS ESSP WMAX IPWP IPWP_FIXED VARIANCE SD ENTROPY;
 id METHOD2 SET_TOLS;
 by SIM TREAT;
run;

data d4;
 set d3;
 DPS=POLYMAIC1SIG_TOLS-SIGNMAICNA;
 DPJ=POLYMAIC1SIG_TOLS-JACKMAICNA;
 DJS=JACKMAICNA-SIGNMAICNA;
 DIPS=POLYMAIC2SUCCESS_CRIT-SIGNMAICNA;
 DIPJ=POLYMAIC2SUCCESS_CRIT-JACKMAICNA;
run;

proc transpose data=d4 out=d5;var DPS DPJ DJS DIPS DIPJ;id _NAME_ ;by SIM TREAT;run;

data d6; 
 format SIM 5.0 METHOD2 $25. SET_TOLS SUCCESS;
 set d2 d5;
 if _NAME_='DPS'  then METHOD2='POLY vs SIGN: SIGN tols.';
 if _NAME_='DPJ'  then METHOD2='POLY vs JACK: SIGN tols.';
 if _NAME_='DJS'  then METHOD2='JACK vs SIGN';
 if _NAME_='DIPS' then METHOD2='POLY vs SIGN: IND tols.';
 if _NAME_='DIPJ' then METHOD2='POLY vs JACK: IND tols.';
 rename SIM=SCENARIO;
 label SIM='Scenario #'
       ESS='Effective sampe size'
       ESSP='Effective sampe size (%)'
       ENTROPY='Shannon entropy'
       WMAX='Maximum weight'
	   VARIANCE='Weight variance'
	   SD='Weight SD'
	   IPWP='% weights >=0.05*N'
       IPWP_FIXED='% weights>=5'
       METHOD2='Re-weight method'
	   SET_TOLS='PolyMAIC tolerances'
;
 drop _NAME_ ;
run;

proc sort data=d6;by SCENARIO TREAT descending METHOD2;run;

/*
a)	Scenarios A: PolyMAIC achieved SignMAIC-levels of matching success. 
b)	Scenarios B: Scenarios A where SignMAIC ESS %s were estimated to be 20 to 80%. 
c)	Scenarios C: Both methods achieved independent levels of matching success. 
*/

data sessp;
 set d6;
 if METHOD2='SIGNMAIC';
 keep SCENARIO TREAT ESSP;
run;

data d8; 
 merge failfl
       sessp;
 by SCENARIO; 
 if failfl=''                           then GROUPA='Yes'; 
 if GROUPA='Yes' and 20<=ESSP<=80       then GROUPB='Yes'; 

 label GROUPA='Scenarios A' GROUPB='Scenarios B' GROUPC='Scenarios C';
 drop _NAME_ _LABEL_ ESSP;
run;


proc freq data=d8;table GROUP: GROUPA*GROUPB  / list missing;run;

data ad.ADMETRICS_UNANCH;
 merge d6 d8;
 by SCENARIO TREAT;
run;

proc sort data=ad.ADMETRICS_UNANCH;by SCENARIO TREAT descending METHOD2;run;

* eof;

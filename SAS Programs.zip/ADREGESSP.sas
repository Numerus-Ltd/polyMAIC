/************************************************************************
Numerus Ltd

Purpose            : Creates an AD for the ESS % regression analyses

************************************************************************/;


libname ad 'path\SAS Files';

data d1;
 set ad.ADMETRICS;
 if METHOD='Difference: Sig. tols.';
 keep SCENARIO ESSP;
run;
data base;
 set ad.ADSUCCESS;
 if  0<=SIGNESSP<=20 then SIGNESSPC='1:ESSP   0-20 ';
 if 20<SIGNESSP<=40  then SIGNESSPC='2:ESSP >20-40';
 if 40<SIGNESSP<=60  then SIGNESSPC='3:ESSP >40-60';
 if 60<SIGNESSP<=80  then SIGNESSPC='4:ESSP >60-80';
 if 80<SIGNESSP<=100 then SIGNESSPC='5:ESSP >80-100';
 label SIGNESSPC='SignMAIC ESS % (cat.)';
 keep SCENARIO--GROUPC X1n--XD5 SIGNESSPC BINSUM--VARSUM;
run;

proc freq;table SIGNESSPC;run;

proc corr data=AD.DATA  outs=outs noprint;
 var Xdata1 Xdata2 Xdata3 Xdata4 Xdata5;
 by SCENARIO;
run;
data c1;
 set outs;
 if _TYPE_='CORR';
 if _NAME_='Xdata1' then Xdata1=.;
 if _NAME_='Xdata2' then Xdata2=.;
 if _NAME_='Xdata3' then Xdata3=.;
 if _NAME_='Xdata4' then Xdata4=.;
 if _NAME_='Xdata5' then Xdata5=.;
 max=max(abs(Xdata1),abs(Xdata2),abs(Xdata3),abs(Xdata4),abs(Xdata5));
 men=mean(abs(Xdata1),abs(Xdata2),abs(Xdata3),abs(Xdata4),abs(Xdata5));
run;
proc means data=c1 noprint;
 var max men;
 by SCENARIO;
 output out=ss1 max=CORRMAX mean=CORRMEAN;
run;

proc sort data=d1  ;by SCENARIO;run;
proc sort data=base;by SCENARIO;run;
proc sort data=c1  ;by SCENARIO;run;

data d2;
 merge base d1 ss1;
 by SCENARIO;
 format CORRMAX CORRMEAN 5.2;
 _TYPE_=0;
 label CORRMAX='Correlation: maximum' CORRMEAN='Correlation: mean';
run;

data AD.ADREGESSP;
 set d2;
  if      CORRMEAN<=0.1  then CORRMEANC='1: Corr  0.0-0.1';
  if  0.1<CORRMEAN<=0.2  then CORRMEANC='2: Corr >0.1-0.2';
  if  0.2<CORRMEAN<=0.3  then CORRMEANC='3: Corr >0.2-0.3';
  if  0.3<CORRMEAN<=0.4  then CORRMEANC='4: Corr >0.3-0.4';
  if  0.4<CORRMEAN       then CORRMEANC='5: Corr >0.4-1.0';
 label CORRMEANC='Correlation: mean (cat.)';
 drop _TYPE_ _FREQ_;
run;

proc freq data=AD.ADREGESSP;table CORRMEANC;run;

proc gchart data=AD.ADREGESSP;vbar corrmean;run;quit;run;

* eof;
